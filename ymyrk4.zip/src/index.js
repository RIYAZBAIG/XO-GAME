import React from "react";
import ReactDom from "react-dom";
import "./styles.css";
import Game from "./Components/Game";

ReactDom.render(<Game />, document.getElementById("root"));